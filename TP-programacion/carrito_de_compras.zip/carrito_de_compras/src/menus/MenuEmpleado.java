package menus;

public class MenuEmpleado {

}
