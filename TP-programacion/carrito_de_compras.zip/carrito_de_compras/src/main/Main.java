package main;

import java.util.Scanner;

import contenedores.ListadoArticulos;
import models.Articulo;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ListadoArticulos la = new ListadoArticulos();
		Scanner sc = new Scanner(System.in);
		boolean state = true;
		int contador = 0;
		
		
		

		while (state) {
			
			System.out.println("1-Mostrar articulos");
			System.out.println("2-Agregar articulo");
			System.out.println("3-modificar articulo");
			System.out.println("4-Eliminar articulo");
			System.out.println("5-Salir");
			System.out.println("Ingrese una opcion");

			int opcion = sc.nextInt();
			switch (opcion) {
			case 1:
				if(la.MostrarListadoArticulos() == false)
				{
					System.out.println("La lista no contiene articulos.");
				}
				
				
				break;
			case 2:
				
				System.out.println("Ingrese el nombre del articulo:");
				String nombreArticulo = sc.next();

				System.out.println("Ingrese el precio:");
				double precio = sc.nextDouble();

				System.out.println("Ingrese una descripcion breve:");
				String descripcion = sc.next();

				Articulo art = new Articulo(contador+1,precio, nombreArticulo, descripcion);
				
				boolean exito = la.agregar(art);
				
				if(exito) {
					System.out.println("El articulo se agrego correctamente.");
					contador++;
				}else {
					System.out.println("No se pudo crear el articulo, intentelo nuevamente mas tarde.");
				}				
				break;
			case 3:
				state = false;
				break;
			case 4:
				
				la.MostrarListadoArticulos();
				System.out.println("Ingrese el numero de articulo que desea eliminar:");
				int numeroArticulo = sc.nextInt();
				
				Articulo getArticulo = la.buscar(numeroArticulo-1);
				
				if(la.eliminar(getArticulo)) 
				{
					System.out.println("El articulo se elimino correctamente...");
				}
				else
				{
					System.out.println("Ha ocurrido un error al eliminar el articulo...");
				}
				break;
			case 5:
				state = false;
				break;
			default:
				
				break;
			}
		}

	}

}
