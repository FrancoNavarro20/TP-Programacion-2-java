package models;

public class Cliente {
	
	private String usuario;
	private String password;
	private String saldo;
	
}
