package models;

public class Empleado {

	private String usuario;
	private String password;
	
}
